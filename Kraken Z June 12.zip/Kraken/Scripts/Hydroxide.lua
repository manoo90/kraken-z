loadstring(game:HttpGetAsync("https://raw.githubusercontent.com/nrv-ous/Hydroxide/rebirth/init.lua"))()

oh.ui = import(4635451696)
oh.assets = import(4636445983)

oh.message = import("message_box.lua")
oh.explorer = import("explorer.lua")

oh.upvalue_scanner = import("upvalue_scanner.lua")

oh.execute()

