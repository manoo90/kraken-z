-- Dark Spy V0.0.1
-- Developed by Simplicity#4572
loadstring(game:HttpGet("https://pastebin.com/raw/SwZq0zCf"))()