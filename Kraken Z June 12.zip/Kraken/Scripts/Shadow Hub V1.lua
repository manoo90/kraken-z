_G.key = "TrialKey1" -- Key here

--[[
--------------------------------------
Shadow Hub V1
--------------------------------------
--]]

loadstring(game:HttpGet("https://pastebin.com/raw/uMuX03r7",true))()